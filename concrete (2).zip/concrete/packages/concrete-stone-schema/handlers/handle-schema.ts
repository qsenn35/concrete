import {
  MooLexer,
  StateMachine,
  TypeDefContext,
  FormatLexerResult,
} from "../types.ts";
import { handleBlock } from "./handle-blocks.ts";

export function handleTypeDef(lexer: MooLexer) {
  const ctx: TypeDefContext = {
    category: "type",
    name: undefined,
    descriptors: [],
    formats: [],
  };

  const handler = (
    ctx: TypeDefContext,
    value: string | number | boolean | FormatLexerResult
  ) => {
    return;
  };

  const stateMachine: StateMachine = {
    current: "schema_def",
    steps: {
      schema_def: {
        next: ["identifier"],
      },
      open_curly: {
        next: ["prop_identifier"],
      },
      open_paren: {
        next: ["identifier", "format"],
      },
      close_paren: {
        next: ["end_line"],
      },
      end_line: {
        next: ["prop_identifier", "close_curly"],
      },
      format: {
        handler,
        next: ["comma", "close_paren"],
      },
      identifier: {
        handler,
        next: ["open_curly", "comma", "close_paren"],
      },
      propIdentifier: {
        handler,
        next: ["open_paren"],
      },
      punctuation: {
        next: ["identifier"],
      },
      comma: {
        next: ["identifier", "format", "close_paren"],
      },
    },
  };

  return handleBlock(lexer, ctx, stateMachine);
}
