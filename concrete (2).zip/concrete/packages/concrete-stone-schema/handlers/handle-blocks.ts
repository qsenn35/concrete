import {
  ContextType,
  MooLexer,
  MooLexerResult,
  StateMachine,
  StateMachineStepHandler,
} from "../types.ts";

export function handleBlock<THandle extends StateMachineStepHandler>(
  lexer: MooLexer,
  ctx: ContextType,
  stateMachine: StateMachine<THandle>
) {
  let token: MooLexerResult | undefined = lexer.next();
  while (
    stateMachine.steps[stateMachine.current]?.next &&
    stateMachine.steps[stateMachine.current]?.next?.length
  ) {
    if (!token || token.type === "ws" || token.type === "comment") {
      continue;
    }

    const currentStep = stateMachine.steps[stateMachine.current];
    console.log(
      "Current Step:",
      stateMachine.current,
      token.value,
      currentStep.handler,
      currentStep.next
    );

    if (currentStep?.handler) {
      currentStep.handler(ctx, token.value);
    }

    stateMachine.current = token.type;
    token = lexer.next();
  }

  return ctx;
}
