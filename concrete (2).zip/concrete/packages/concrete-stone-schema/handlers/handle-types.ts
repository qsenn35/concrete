import {
  MooLexer,
  StateMachine,
  TypeDefContext,
  FormatLexerResult,
} from "../types.ts";
import { handleBlock } from "./handle-blocks.ts";

const handleIdentifier = (ctx: TypeDefContext, value: string) => {
  if (ctx.type === undefined) {
    ctx.type = value;
    return;
  }
  if (typeof value !== "string") return;

  ctx.descriptors.push(value);
};

const handleFormat = (ctx: TypeDefContext, value: FormatLexerResult) => {
  ctx.formats.push(value);
};

export function handleTypeDef(lexer: MooLexer) {
  const ctx: TypeDefContext = {
    category: "type",
    type: undefined,
    descriptors: [],
    formats: [],
  };

  const handler = (
    ctx: TypeDefContext,
    value: string | number | boolean | FormatLexerResult
  ) => {
    if (typeof value === "string") return handleIdentifier(ctx, value);

    return handleFormat(ctx, value as FormatLexerResult);
  };

  const stateMachine: StateMachine = {
    current: "type_def",
    steps: {
      type_def: {
        next: ["identifier"],
      },
      open_paren: {
        next: ["identifier", "format"],
      },
      close_paren: {
        next: [],
      },
      format: {
        handler,
        next: ["comma", "close_paren"],
      },
      identifier: {
        handler,
        next: ["punctuation", "comma", "open_paren", "close_paren"],
      },
      punctuation: {
        next: ["identifier"],
      },
      comma: {
        next: ["identifier", "format", "close_paren"],
      },
    },
  };

  return handleBlock(lexer, ctx, stateMachine);
}
