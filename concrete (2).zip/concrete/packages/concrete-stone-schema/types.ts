export type FormatLexerResult = {
  type: string;
  args: Array<string | number | boolean>;
};

export type MooLexerResult = {
  type: string;
  value: string | number | boolean | FormatLexerResult;
  text: string;
  toString: () => string;
  offset: number;
  lineBreaks: number;
  line: number;
  col: number;
};

export type MooLexer = {
  reset: (input: string) => void;
  next: () => MooLexerResult;
};

export type TypeDefContext = {
  category: "type";
  type: string | undefined;
  descriptors: Array<string>;
  formats: Array<FormatLexerResult>;
};

export type TypeIdentifierHandler = (
  ctx: TypeDefContext,
  value: string
) => void;
export type TypeFormHandler = (
  ctx: TypeDefContext,
  value: FormatLexerResult
) => void;

export type ContextType = TypeDefContext;

export type StateMachineStepHandler = (
  ctx: ContextType,
  value: MooLexerResult["value"]
) => void;

export type StateMachine<
  THandle extends StateMachineStepHandler = StateMachineStepHandler
> = {
  current: string;
  steps: {
    [key: string]: {
      handler?: THandle;
      next: string[];
    };
  };
};
