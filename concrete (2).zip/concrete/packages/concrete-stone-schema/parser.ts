import { handleTypeDef } from "./handlers/handle-types.ts";
import { lexer } from "./lexer.ts";

export function tokenize(input: string) {
  lexer.reset(input);

  const blocks: any[] = [];

  let token;
  while ((token = lexer.next())) {
    if (token.type === "ws" || token.type === "comment") {
      continue;
    }
    // console.log(token.type);
    if (token.type === "type_def") {
      const typeResult = handleTypeDef(lexer);
      blocks.push(typeResult);
    }
  }

  console.log(blocks);

  return blocks;
}

tokenize(`
type basicNum (
  number,
)

type basicString (
  string,
)

type basicBoolean (
  boolean,
)
`);
