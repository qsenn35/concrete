const kv = await Deno.openKv();

export default kv;