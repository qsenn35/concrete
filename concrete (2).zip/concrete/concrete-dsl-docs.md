# Concrete Schema DSL

## Disclaimer

**You do not *have* to use Concrete's Schema DSL.** All functionality is accessible through using Concrete's enhanced version of `zod`.
This is purely syntatic sugar to make schema defining less tedious.

## Intro.

Concrete requires a `zod` schema definition to function. However, the whole goal of Concrete is to limit how many times you need to describe your data.
Because of this, concrete comes with a Domain-Specific-Language to define your schemas. Under the hood, these will resolve to `zod` schemas with some enhancement to allow concrete to understand more about your data.

Concrete's DSL is 1-1 compatible with `zod` and therefore TypeScript & JSONSchema as well!

## Descriptor

Descriptors are any tokens that you use when describing your schema & module properties. Descriptors can be formats, types, configs, and schemas.

## Types

Expect that any `zod` datatype is included in Concrete's DSL by default.

```
...
propertyName: (type);
...
```

## Formats

Formats are descriptors that specify the, well, "format" of the data. These can be things like string lengths, numerical ranges, and even regex patterns. Any format descriptor available in `zod` is available in Concrete.

```
...
propertyName: (type, format());
...
```

## Configs

Configs are a unique descriptor as techinically they don't describe the data directly.
Instead, they are used to pass values to the post-compile step to add to the result.
Below in our Schema example, we specify a config called `primary`. After compilation, we will be able to access the property `_$concrete_primary` to check if this property is the primary key of the Schema.
Think of configs as way to tell Concrete meta information about your data.

```
config Name {
  customPropery: value;
}
```

## Custom Descriptors

### Custom Types

You can define custom types which can be (and typically are) collections of descriptors.

```
type email (
  string,     
  minLength(3), 
  maxLength(255),
  regex(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$/)
)

type uid (
  string,
  length(36),
  regex(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i)
)
```

### Formats

Custom Formats are used typically to collect multiple formats for resuse in types/schemas.

#### Example: Positive Number Format
```
format positiveNumber (
  min(1),
)
```

### Configs

Custom Configs can also be written if you decide you want to pass extra data. The use case is typically for extending Concrete or implementing on top of Concrete's DSL.

```
config primary {
  _$concrete_primary: true;
}
```

## Putting it all together with Schemas

Schemas are the bread and butter of Concrete's DSL, they are collections of property->descriptor pairs and some extra configuration properties.

### Scopes

By default, all properties in a Concrete Schema are `private`. Meaning, none of your properties are available to the client unless otherwise specified.
Scopes are used to define data access for properties in your Schema.
In the example below, we use the predifined `@public` scope to tell Concrete that these properties should be accessible to the client.

**Custom Scopes are not available at this time.**

#### Example:
```

schema UserSchema {
  id: (primary, bigint);
  uid: (string, uid);
  email: (string, email);

  :@public {
    displayName: (string, minLength(3));
    username: (string, minLength(3));
    bio: (string);
    avatarUrl: (string);
  }
}

...or...

@public UserSchema {
  displayName: (string, minLength(3));
  username: (string, minLength(3));
  bio: (string);
  avatarUrl: (string);
}

```

## Modules

Last but not least, we have modules. Modules are similar to schema in syntax, but also include the option to specify procedure arguments and return types.
You can use the `with` keyword to specify a Schema that this module implements.

```
module User with UserSchema {
  @public {
    get(id: number): (User);
    getByEmail(email: string): (User);
    getByUUID(uuid: string): (User);
  }
}
```